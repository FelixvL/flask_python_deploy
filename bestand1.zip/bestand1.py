import pandas as pd

def eenmethodeinbestand1():
    return "dit komt uit methode 1"


def methodeMetReadFile():
    #pokemons = pd.read_csv("externebestanden/Pokemon.csv")
    #kolomnaam = pokemons.columns[4] 
    return "kolomnaam"


#methodeMetReadFile()